
export type Language = 'html' | 'css' | 'javascript';
